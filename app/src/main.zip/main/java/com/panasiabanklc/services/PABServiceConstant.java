package com.panasiabanklc.services;

/**
 * Created by user1 on 8/6/2017.
 */

public class PABServiceConstant {

    public static String URL_LOGIN="http://192.168.43.131/pan_asia/public/auth";
    public static String NEW_CUST_REGISTER="http://192.168.43.131/pan_asia/public/createAccount";
    public static String ACCOUNT_DETAIL_BYID="http://192.168.43.131/pan_asia/public/accountDetailById";
    public static String URL_LOAN_APPLICATION="http://192.168.43.131/pan_asia/public/loanApply";
    public static String URL_LOAN_DETAIL_BYID="http://192.168.43.131/pan_asia/public/loadDetailById";
    public static String URL_LOCATION="http://192.168.43.131/pan_asia/public/location";
    public static String URL_CUST_ONBOARD="http://192.168.43.131/pan_asia/public/customer";

}
