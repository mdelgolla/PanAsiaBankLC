package com.panasiabanklc.activities;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.panasiabanklc.PABUserLoginActivity;
import com.panasiabanklc.R;
import com.panasiabanklc.services.PABServiceConstant;
import com.panasiabanklc.utility.PABCheckNetworkConnection;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by user1 on 8/6/2017.
 */

public class PABNewCustAccountOpeningActivity extends AppCompatActivity implements View.OnClickListener {
    private Spinner accounttype,spin_modeof_contact;
    private ImageView header_left,btnmenu;
    private ProgressDialog mProgressDialog;
    private String progressTitle = "",progressMessage = "";
    private EditText et_full_name, et_address, et_nic_number,et_mobile,et_home_tel,et_office_tel,et_email_add;
    private Button btn_new_account;
    private TextView tv_loan_calculator;
    private RadioGroup rg_get_title;
    private String radiovalue, account, username,contact_mode;
    private RadioButton rb_rev,rb_mr,rb_mrs,rb_miss;
   // private AwesomeValidation awesomeValidation;
    static PABNewCustAccountOpeningActivity activity = null;

    protected void onCreate(Bundle savedInstantState) {
        super.onCreate(savedInstantState);

        //awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        activity = this;

        setContentView(R.layout.pab_new_cust_account);
        initViews();
    }

    public void initViews() {
        header_left = (ImageView) findViewById(R.id.btn_header_left);
        header_left.setOnClickListener(this);
        btnmenu=(ImageView)findViewById(R.id.btnmenu);
        btnmenu.setOnClickListener(this);
        et_full_name = (EditText) findViewById(R.id.et_full_name);
        et_address = (EditText) findViewById(R.id.et_address);
        et_nic_number = (EditText) findViewById(R.id.et_nic_number);
        et_mobile=(EditText)findViewById(R.id.et_mobile);
        et_home_tel=(EditText)findViewById(R.id.et_home_tel);
        et_office_tel=(EditText)findViewById(R.id.et_office_tel);
        et_email_add=(EditText)findViewById(R.id.et_email_add) ;
        btn_new_account = (Button) findViewById(R.id.btn_new_account);
        btn_new_account.setOnClickListener(this);
        tv_loan_calculator=(TextView)findViewById(R.id.tv_loan_calculator) ;
        tv_loan_calculator.setText("ACCOUNT OPENING");
        rg_get_title=(RadioGroup) findViewById(R.id.rg_get_title);
        Log.i("Radiovalue",":"+radiovalue);
        accounttype=(Spinner) findViewById(R.id.sp_accounttype);
        spin_modeof_contact=(Spinner) findViewById(R.id.spin_modeof_contact);

        //awesomeValidation.addValidation(this, R.id.et_full_name, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.enter_name);

        SharedPreferences preferences = getApplicationContext().getSharedPreferences("pabloancalculatordefaults", PABNewCustAccountOpeningActivity.this.MODE_PRIVATE);
        username=preferences.getString("Username","");
        Log.i("username",":"+username);

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setCancelable(false);

    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_new_account:
                Log.i("RegisterUser"," : Clicked");
                try{
                    int validateCode = validateInputData(202);
                    radiovalue=((RadioButton)this.findViewById(rg_get_title.getCheckedRadioButtonId())).getText().toString();
                    account=accounttype.getSelectedItem().toString();
                    contact_mode=spin_modeof_contact.getSelectedItem().toString();

                    Log.i("RegisterUser"," : " + validateCode);
                    if (validateCode == 202) {
                        Log.i("RegisterUser"," Submit 1: " + validateCode);
                        newAccountRegister();
                    }else{
                        Log.i("RegisterUser",":" + validateCode);
                    }
                }catch (Exception e){
                    Log.i("RegisterUser",":" + e);
                    // Tracking exception
                    //LECApplicationActivity.getInstance().trackException(e);
                }

                break;
            case R.id.btn_header_left:
                onBackPressed();
                break;
            case R.id.btnmenu:
                PopupMenu popup = new PopupMenu(activity, btnmenu);
                //Inflating the Popup using xml file
                popup.getMenuInflater().inflate(R.menu.pab_popup_menu, popup.getMenu());

                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        SharedPreferences preferences = getApplicationContext().getSharedPreferences("pabloancalculatordefaults", PABNewCustAccountOpeningActivity.this.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intent=new Intent(activity, PABUserLoginActivity.class);
                        startActivity(intent);
                        finish();
                        Log.i("username",":");
                        return true;
                    }
                });

                popup.show();//showing popup menu
                break;
            default:
                break;
        }
    }
    public void newAccountRegister() {
        try {
            int validationCode = validateInputData(202);
            Toast.makeText(getApplicationContext(), "validateCode 1 :" + validationCode, Toast.LENGTH_SHORT).show();
            if (validationCode == 202) {
//                if (PABCheckNetworkConnection.isConnectionAvailable(getApplicationContext())) {
                    Toast.makeText(getApplicationContext(), "getAllAccountDetail 2:" + validationCode, Toast.LENGTH_SHORT).show();
                    new AccountOpeningApplication().execute(radiovalue,et_full_name.getText().toString().trim(),et_address.getText().toString().trim(),et_nic_number.getText().toString().trim(),account,et_mobile.getText().toString().trim(),et_home_tel.getText().toString().trim(),et_office_tel.getText().toString().trim(),et_email_add.getText().toString().trim(),
                            contact_mode,username);
                    //registerUser(et_username.getText().toString(),et_email.getText().toString(),et_firstname.getText().toString(),et_lastname.getText().toString(),et_password.getText().toString(),"","1",getCurrentDate(),getCurrentDate(),"1");
//                } else {
//                    //displayValidation("Please check the network connection");
//                    Toast.makeText(getApplicationContext(), "Please check the network connection", Toast.LENGTH_SHORT).show();
//                }
            }
        } catch (Exception e) {
            Log.i("Account Submit", ":" + e);

        }

    }

    class AccountOpeningApplication extends AsyncTask<String, String, String>{
        @Override
        protected void onPreExecute() {
            Log.i("onpreexecute",":");
            super.onPreExecute();
            progressTitle = getString(R.string.loading_message);
            progressMessage = getString(R.string.loan_submit);
            viewProgressDialog(progressTitle, progressMessage);
        }

        @Override
        protected String doInBackground(String... params) {
          Log.i("result_1",":");
          String accountSubmitResult = "";

            try{
                DefaultHttpClient httpClient = new DefaultHttpClient();
                // HttpGet httpGet = new HttpGet(url);
                HttpPost httpPost = new HttpPost(PABServiceConstant.NEW_CUST_REGISTER);
                List<NameValuePair> nameValuePairs = new
                        ArrayList<NameValuePair>(11);
                Log.i("AccountRegister",":"+params[0]+"|"+params[1]+"|"+params[2]+"|"+params[3]+"|"+params[4]+"|"+params[5]);
                nameValuePairs.add(new BasicNameValuePair("title",params[0]));
                nameValuePairs.add(new BasicNameValuePair("name",params[1]));
                nameValuePairs.add(new BasicNameValuePair("address",params[2]));
                nameValuePairs.add(new BasicNameValuePair("nic",params[3]));
                nameValuePairs.add(new BasicNameValuePair("type",params[4]));
                nameValuePairs.add(new BasicNameValuePair("mobile",params[5]));
                nameValuePairs.add(new BasicNameValuePair("home",params[6]));
                nameValuePairs.add(new BasicNameValuePair("office",params[7]));
                nameValuePairs.add(new BasicNameValuePair("email",params[8]));
                nameValuePairs.add(new BasicNameValuePair("mode",params[9]));
                nameValuePairs.add(new BasicNameValuePair("user",params[10]));

                httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                //username,email,firstname,lastname,password,profileimg,userroleuid,creationdate,modifiedby,isactive
                try {
                    HttpResponse response= httpClient.execute(httpPost); // some response object
                    BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
                    accountSubmitResult = reader.readLine();
                    Log.i("shiv", "valeLogin:" + accountSubmitResult);
                }catch (Exception e){
                    Log.i("reg_fail",":"+e);
                }

            }catch (Exception e){
                Log.i("reg_fail_1",":"+e);
            }

           return accountSubmitResult;
        }

        @Override
        protected void onPostExecute(String result) {
            Log.i("onpostexecute",":");
            dissmissProgressDialog();
            Log.i("LoanApplicationRegistry", ":" + result);

            boolean response = false;
            String message ="";
            try{
                JSONObject jsonResponse = new JSONObject(result);
                if (!jsonResponse.isNull("response")) {
                    response = jsonResponse.getBoolean("response");
                }
                if(response == true) {
                    alertDialog();
                }else{
                    Toast.makeText(getApplicationContext(), "Loan Registration Failed. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }catch (Exception e){
                Toast.makeText(getApplicationContext(), "Loan Registration Fail :" + e, Toast.LENGTH_SHORT).show();
            }

        }

    }
    public void alertDialog(){
        AlertDialog.Builder alertDialog=new AlertDialog.Builder(PABNewCustAccountOpeningActivity.this);
        alertDialog.setTitle("New Account Register");
        alertDialog.setMessage("Do you want to save a new customer?");
        alertDialog.setPositiveButton("YES",new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int which){
                SharedPreferences preferences = getApplicationContext().getSharedPreferences("pabnewcutaccountdefault", PABNewCustAccountOpeningActivity.this.MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("NICNumber", et_nic_number.getText().toString().trim());
                editor.commit();
                Intent submit = new Intent(getApplicationContext(), PABExistingCustAccountActivity.class);
                startActivity(submit);
                finish();

            }
        });
        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int which){

            }
        });
        alertDialog.setNeutralButton("CANCEL",new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int which){

            }
        });
        alertDialog.show();

    }

    public int validateInputData(int validationCode) {
        if (et_full_name.getText().toString().trim().length()<3){
            validationCode = 404;
            viewErrorValidation(getString(R.string.account_register), getString(R.string.enter_name), 404);
        }
        else if (et_address.getText().toString().trim().length()<3){
            validationCode = 404;
            viewErrorValidation(getString(R.string.account_register), getString(R.string.enter_addres), 404);
        }
        else if (et_nic_number.getText().toString().trim().length()!=10){
            validationCode = 404;
            viewErrorValidation(getString(R.string.account_register), getString(R.string.enter_nic), 404);
        }
        if (et_mobile.getText().toString().trim().length()!=10){
            validationCode = 404;
            viewErrorValidation(getString(R.string.account_register), getString(R.string.enter_mobile), 404);
        }
        else if (et_home_tel.getText().toString().trim().length()!=10){
            validationCode = 404;
            viewErrorValidation(getString(R.string.account_register), getString(R.string.enter_hometel), 404);
        }
        else if (et_office_tel.getText().toString().trim().length()!=10){
            validationCode = 404;
            viewErrorValidation(getString(R.string.account_register), getString(R.string.enter_officetel), 404);
        }
        else if (et_email_add.getText().toString().trim().length()<3){
            validationCode = 404;
            viewErrorValidation(getString(R.string.account_register), getString(R.string.enter_email), 404);
        }

     return validationCode;
    }

    public  void viewErrorValidation(String msgTitle, String msgBody,final int validationCode ){
        AlertDialog.Builder builder=new AlertDialog.Builder(PABNewCustAccountOpeningActivity.this);
        builder.setTitle(msgTitle);
        builder.setMessage(msgBody);
        builder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }

                });
        builder.show();

    }



    public void onBackPressed() {
        Intent intent = new Intent(activity, PABAccountOpeningActivity.class);
        activity.finish();
        startActivity(intent);
        overridePendingTransition(R.anim.abc_fade_in, R.anim.abc_fade_out);
    }

    public void viewProgressDialog(String progressTitleStr,String progressMessageStr){
        Log.i("onpreexecute_1",":");
        if(!mProgressDialog.isShowing()){
            mProgressDialog = new ProgressDialog(PABNewCustAccountOpeningActivity.this);
            mProgressDialog.setMax(100);
            mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            mProgressDialog.setCancelable(false);
            // Set progressdialog title
            mProgressDialog.setTitle(progressTitleStr);
            // Set progressdialog message
            mProgressDialog.setMessage(progressMessageStr);
            mProgressDialog.setIndeterminate(false);
            // Show progressdialog
            mProgressDialog.show();
        }
    }


    public void dissmissProgressDialog(){
        if(mProgressDialog.isShowing()){
            mProgressDialog.dismiss();
        }
    }

}
